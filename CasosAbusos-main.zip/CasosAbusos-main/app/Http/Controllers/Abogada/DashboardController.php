<?php

namespace App\Http\Controllers\Abogada; 

use App\Http\Controllers\Controller;
use App\Models\Caso;
use App\Models\Seguimiento;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $abogadaId = Auth::id(); 

        $baseQuery = fn($estado) => Caso::where('usuario_id', $abogadaId)
                                        ->where('estado', $estado)
                                        ->count();

        $casosActivosCount = $baseQuery('activo');
        $casosEnJuicioCount = $baseQuery('En Juicio');
        $casosSeguimientoExternoCount = $baseQuery('seguimiento_externo');
        $casosCerradosCount = $baseQuery('cerrado');
        
        $estadosParaCitas = ['activo', 'En Juicio', 'seguimiento_externo'];

        $proximasCitas = Seguimiento::whereHas('caso', function ($query) use ($abogadaId, $estadosParaCitas) {
                                        $query->where('usuario_id', $abogadaId)
                                              ->whereIn('estado', $estadosParaCitas); 
                                    })
                                    ->whereNotNull('proxima_cita')
                                    ->where('proxima_cita', '>=', Carbon::today())
                                    ->orderBy('proxima_cita', 'asc')
                                    ->with('caso') 
                                    ->take(5) 
                                    ->get();

        return view('abogada.dashboard', compact(
            'casosActivosCount',
            'casosEnJuicioCount', 
            'casosSeguimientoExternoCount',
            'casosCerradosCount',
            'proximasCitas'
        ));
    }
}