<?php

namespace App\Http\Controllers\Abogada;

use App\Http\Controllers\Controller;
use App\Models\Formulario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GestionFormularioController extends Controller
{
    private $allowedAreas = ['juridica', 'ambas'];
    private $forbiddenArea = 'psicologica';
    private $viewPath = 'abogada.gestion-formularios';
    private $routePrefix = 'abogada.gestion-formularios';

    public function index(Request $request)
    {
        $query = Formulario::query();
        if ($request->filled('search')) {
            $query->where('nombre', 'like', '%' . $request->search . '%');
        }
        $formularios = $query->whereIn('area', $this->allowedAreas)
                             ->orderBy('created_at', 'desc')
                             ->paginate(10);
        $formularios->loadCount('preguntas');

        return view("{$this->viewPath}.index", compact('formularios'));
    }

    public function create()
    {
        return view("{$this->viewPath}.create");
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:200', 
            'tipo' => 'required|in:ingreso,seguimiento,evaluacion', 
            'area' => 'required|in:psicologica,juridica,ambas', 
        ]);

        if ($validated['area'] === $this->forbiddenArea) {
             return back()->withErrors(['area' => 'No puedes crear un formulario exclusivo del área psicológica. Selecciona "Jurídica" o "Ambas".'])->withInput();
        }

        $formulario = new Formulario($validated);
        $formulario->creado_por = Auth::id(); 
        $formulario->activo = true;
        $formulario->save();

        return redirect()->route("{$this->routePrefix}.edit", $formulario)
                         ->with('success', 'Formulario creado. Ahora puedes añadir preguntas.');
    }

    public function edit(Formulario $gestion_formulario) 
    {
         if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
             abort(403, 'No tienes permiso para editar este formulario.');
         }
        $formulario = $gestion_formulario->load('preguntas'); 
        return view("{$this->viewPath}.edit", compact('formulario'));
    }

     public function update(Request $request, Formulario $gestion_formulario) 
    {
         if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
             abort(403, 'No tienes permiso para actualizar este formulario.');
         }
         
        $validated = $request->validate([
            'nombre' => 'required|string|max:200',
            'tipo' => 'required|in:ingreso,seguimiento,evaluacion',
            'area' => 'required|in:psicologica,juridica,ambas',
        ]);

        if ($validated['area'] === $this->forbiddenArea) {
             return back()->withErrors(['area' => 'No puedes asignar un formulario exclusivamente al área psicológica. Selecciona "Jurídica" o "Ambas".'])->withInput();
        }

        $gestion_formulario->update($validated);

        return redirect()->route("{$this->routePrefix}.edit", $gestion_formulario)
                         ->with('success', 'Formulario actualizado exitosamente.');
    }

    public function destroy(Formulario $gestion_formulario) 
    {
         if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
             abort(403, 'No tienes permiso para eliminar este formulario.');
         }
        $gestion_formulario->delete();
        return redirect()->route("{$this->routePrefix}.index")
                         ->with('success', 'Formulario eliminado exitosamente.');
    }
}