<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Sesion;
use App\Models\Pregunta;
use App\Models\Respuesta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class RespuestaController extends Controller
{
    use AuthorizesRequests;

    public function store(Request $request, Sesion $sesion)
    {
        $this->authorize('view', $sesion->caso);
        
        $sesion->load('formulario.preguntas');
        
        $reglasValidacion = [];
        $preguntasDelFormulario = $sesion->formulario->preguntas;

        if ($request->input('action') == 'completar') {
            foreach ($preguntasDelFormulario as $pregunta) {
                if ($pregunta->requerida ?? $pregunta->es_obligatoria) {
                    $reglasValidacion['respuestas.'.$pregunta->id] = 'required';
                }
            }
        }

        $request->validate($reglasValidacion, [
            'respuestas.*.required' => 'Esta pregunta es obligatoria.',
        ]);

        $respuestasInput = $request->input('respuestas', []);

        DB::beginTransaction();
        try {
            foreach ($preguntasDelFormulario as $pregunta) {
                $valorRespuesta = $respuestasInput[$pregunta->id] ?? null;
                if (is_array($valorRespuesta)) {
                    $valorRespuesta = json_encode($valorRespuesta);
                }
                Respuesta::updateOrCreate(
                    [
                        'sesion_id' => $sesion->id,
                        'pregunta_id' => $pregunta->id,
                    ],
                    [
                        'respuesta' => $valorRespuesta, 
                    ]
                );
            }
            if ($request->input('action') == 'completar') {
                $sesion->update(['completado' => true]);
            }
            DB::commit();
            if ($request->input('action') == 'completar') {
                return redirect()->route('psicologa.formularios.index', $sesion->caso)
                                 ->with('success', 'Formulario completado exitosamente.');
            }
            return redirect()->route('psicologa.formularios.show', [$sesion->caso, $sesion->formulario])
                             ->with('success', 'Progreso guardado exitosamente.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error al guardar las respuestas: ' . $e->getMessage());
        }
    }
}