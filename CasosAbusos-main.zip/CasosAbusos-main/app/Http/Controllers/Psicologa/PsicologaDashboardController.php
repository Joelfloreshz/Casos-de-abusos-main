<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Caso; 
use App\Models\Seguimiento;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class PsicologaDashboardController extends Controller 
{
    public function index()
    {
        $psicologaId = Auth::id(); 
        $tipoCaso = 'psicologico';

        $baseQuery = fn($estado) => Caso::where('usuario_id', $psicologaId)
                                        ->where('tipo', $tipoCaso)
                                        ->where('estado', $estado)
                                        ->count();

        $casosActivosCount = $baseQuery('activo');
        $casosEnEvaluacionCount = $baseQuery('en_evaluacion');
        $casosEnTerapiaCount = $baseQuery('en_terapia');
        $casosSeguimientoExternoCount = $baseQuery('seguimiento_externo');
        $casosCerradosCount = $baseQuery('cerrado');
        
        $estadosParaCitas = ['activo', 'en_evaluacion', 'en_terapia', 'seguimiento_externo'];

        $proximasCitas = Seguimiento::whereHas('caso', function ($query) use ($psicologaId, $tipoCaso, $estadosParaCitas) {
                                        $query->where('usuario_id', $psicologaId)
                                              ->where('tipo', $tipoCaso) 
                                              ->whereIn('estado', $estadosParaCitas); 
                                    })
                                    ->whereNotNull('proxima_cita')
                                    ->where('proxima_cita', '>=', Carbon::today())
                                    ->orderBy('proxima_cita', 'asc')
                                    ->with('caso') 
                                    ->take(5) 
                                    ->get();

        return view('psicologa.dashboard', compact(
            'casosActivosCount',
            'casosEnEvaluacionCount',
            'casosEnTerapiaCount',
            'casosSeguimientoExternoCount',
            'casosCerradosCount',
            'proximasCitas'
        ));
    }
}