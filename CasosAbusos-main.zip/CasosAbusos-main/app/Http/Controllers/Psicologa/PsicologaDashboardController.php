<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Caso; 
use App\Models\Seguimiento;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class PsicologaDashboardController extends Controller 
{
    public function index()
    {
        $psicologaId = Auth::id(); 

        $estadosActivosPsicologia = ['activo', 'en_evaluacion', 'en_terapia', 'seguimiento_externo'];

        $casosActivosCount = Caso::where('usuario_id', $psicologaId)
                                 ->where('tipo', 'psicologico') 
                                 ->whereIn('estado', $estadosActivosPsicologia) 
                                 ->count();

        $casosCerradosCount = Caso::where('usuario_id', $psicologaId)
                                  ->where('tipo', 'psicologico') 
                                  ->where('estado', 'cerrado')
                                  ->count();

        $proximasCitas = Seguimiento::whereHas('caso', function ($query) use ($psicologaId, $estadosActivosPsicologia) {
                                        $query->where('usuario_id', $psicologaId)
                                              ->where('tipo', 'psicologico') 
                                              ->whereIn('estado', $estadosActivosPsicologia); 
                                    })
                                    ->whereNotNull('proxima_cita')
                                    ->where('proxima_cita', '>=', Carbon::today())
                                    ->orderBy('proxima_cita', 'asc')
                                    ->with('caso') 
                                    ->take(5) 
                                    ->get();

        return view('psicologa.dashboard', compact(
            'casosActivosCount',
            'casosCerradosCount',
            'proximasCitas'
        ));
    }
}