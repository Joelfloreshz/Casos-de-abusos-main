<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Caso; 
use App\Models\Proyecto; 
use App\Models\User; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class PsicologaCasoController extends Controller
{
    use AuthorizesRequests;

    private $estadosPsicologia = ['activo', 'en_evaluacion', 'en_terapia', 'seguimiento_externo', 'cerrado'];
    private $tipoCaso = 'psicologico';

    private function getValidationRules($casoId = null): array
    {
        $rules = [
            'codigo_caso' => ['required', 'string', 'max:30', Rule::unique('casos')],
            'fecha_ingreso' => ['required', 'date'],
            'estado' => ['required', 'string', Rule::in($this->estadosPsicologia)], 
            'proyecto_id' => ['nullable', 'integer', 'exists:proyectos,id'],
            'nombre_afectada' => ['required', 'string', 'max:150'],
            'dui' => ['nullable', 'string', 'max:10'],
            'edad' => ['nullable', 'integer', 'min:0'],
            'telefono' => ['nullable', 'string', 'max:20'],
            'departamento' => ['nullable', 'string', 'max:50'],
            'municipio' => ['nullable', 'string', 'max:50'],
            'zona' => ['nullable', 'string', Rule::in(['urbana', 'rural'])],
            'motivo' => ['nullable', 'string'],
            'nombre_agresor' => ['nullable', 'string', 'max:150'],
            'parentesco_agresor' => ['nullable', 'string', 'max:100'],
            'estado_civil_agresor' => ['nullable', 'string', 'max:100'],
            'ocupacion_agresor' => ['nullable', 'string', 'max:255'],
        ];

        if ($casoId) {
            $rules['codigo_caso'] = ['required', 'string', 'max:30', Rule::unique('casos')->ignore($casoId)];
        }

        return $rules;
    }

    public function index(Request $request)
    {
        $psicologaId = Auth::id();
        $proyectos = Proyecto::orderBy('nombre')->get();

        $filtros = $request->only(['estado', 'nombre_afectada', 'codigo_caso', 'proyecto_id']);

        $query = Caso::where('usuario_id', $psicologaId)
                     ->where('tipo', $this->tipoCaso) 
                     ->with(['usuario', 'proyecto'])
                     ->orderBy('fecha_ingreso', 'desc');

        $query->when($filtros['estado'] ?? null, function ($q, $estado) {
            return $q->where('estado', $estado);
        });
        $query->when($filtros['nombre_afectada'] ?? null, function ($q, $nombre) {
            return $q->where('nombre_afectada', 'like', '%' . $nombre . '%');
        });
        $query->when($filtros['codigo_caso'] ?? null, function ($q, $codigo) {
            return $q->where('codigo_caso', 'like', '%' . $codigo . '%');
        });
        $query->when($filtros['proyecto_id'] ?? null, function ($q, $proyectoId) {
            return $q->where('proyecto_id', $proyectoId);
        });

        $casos = $query->paginate(10)->appends($filtros);

        $estadosDisponibles = $this->estadosPsicologia;

        return view('psicologa.casos.index', compact('casos', 'proyectos', 'filtros', 'estadosDisponibles'));
    }

    public function create()
    {
        $proyectos = Proyecto::orderBy('nombre')->get();
        $estadosDisponibles = $this->estadosPsicologia;
        return view('psicologa.casos.form', compact('proyectos', 'estadosDisponibles'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate($this->getValidationRules());

        $caso = new Caso($validated);
        $caso->usuario_id = Auth::id();
        $caso->tipo = $this->tipoCaso; 
        $caso->save();

       
        if ($request->input('action') == 'save_and_form') {
             return redirect()->route('psicologa.formularios.index', $caso) 
                              ->with('success', 'Caso registrado. Por favor, llene el formulario.');
        }

        return redirect()->route('psicologa.casos.show', $caso) 
                         ->with('success', 'Caso registrado exitosamente.');
    }

    public function show(Caso $caso)
    {
        $this->authorize('view', $caso);
       
        if ($caso->tipo !== $this->tipoCaso && $caso->estado !== 'seguimiento_externo') {
            if ($caso->usuario_id !== Auth::id()) {
                abort(404);
            }
        }

        $caso->load('proyecto', 'usuario'); 
        return view('psicologa.casos.show', compact('caso'));
    }

    public function edit(Caso $caso)
    {
        $this->authorize('update', $caso);
        if ($caso->tipo !== $this->tipoCaso || $caso->usuario_id !== Auth::id()) {
            abort(404);
        }
        $proyectos = Proyecto::orderBy('nombre')->get();
        $estadosDisponibles = $this->estadosPsicologia;
        return view('psicologa.casos.form', compact('caso', 'proyectos', 'estadosDisponibles'));
    }

    public function update(Request $request, Caso $caso)
    {
        $this->authorize('update', $caso);
        if ($caso->tipo !== $this->tipoCaso || $caso->usuario_id !== Auth::id()) {
             abort(404);
        }

        $validated = $request->validate($this->getValidationRules($caso->id));

        $caso->update($validated);

        return redirect()->route('psicologa.casos.show', $caso) 
                         ->with('success', 'Caso actualizado exitosamente.');
    }

    public function destroy(Caso $caso)
    {
        $this->authorize('delete', $caso);
        if ($caso->tipo !== $this->tipoCaso || $caso->usuario_id !== Auth::id()) {
            abort(404);
        }

        $caso->delete();

        return redirect()->route('psicologa.casos.index') 
                         ->with('success', 'Caso eliminado exitosamente.');
    }
}