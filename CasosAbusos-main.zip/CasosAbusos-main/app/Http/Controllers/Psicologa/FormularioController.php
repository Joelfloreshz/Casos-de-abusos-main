<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Caso;
use App\Models\Formulario;
use App\Models\Sesion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class FormularioController extends Controller
{
    use AuthorizesRequests;

    private function getViewFolder(): ?string
    {
        $user = Auth::user();
        if ($user->isPsicologa()) return 'psicologa';
        return null;
    }

    private function getUserArea(): ?string
    {
        $user = Auth::user();
        if ($user->isPsicologa()) return 'psicologica';
        return null;
    }

    public function index(Caso $caso)
    {
        $viewFolder = $this->getViewFolder();
        $area = $this->getUserArea();

        if (!$area || !$viewFolder) {
            abort(403, 'Rol no válido para acceder a formularios.');
        }

        $this->authorize('view', $caso);

        $formularios = Formulario::where('activo', true)
                                ->where(function ($query) use ($area) {
                                    $query->where('area', $area)
                                        ->orWhere('area', 'ambas');
                                })
                                ->withCount('preguntas')
                                ->orderBy('nombre')
                                ->get();

        $sesionesCompletadas = $caso->sesiones()
                                   ->where('completado', true)
                                   ->where('formulario_id', '!=', null)
                                   ->with('formulario:id,nombre')
                                   ->get()
                                   ->keyBy('formulario_id');

        return view("{$viewFolder}.formularios.index", compact('caso', 'formularios', 'sesionesCompletadas'));
    }

    public function show(Caso $caso, Formulario $formulario)
    {
        $user = Auth::user();
        $viewFolder = $this->getViewFolder();
        $area = $this->getUserArea();

        if (!$viewFolder || !$area) {
             abort(403, 'Rol no válido.');
        }

        $this->authorize('view', $caso);

        if (!in_array($formulario->area, [$area, 'ambas'])) {
            abort(403, 'Este formulario no es aplicable para tu rol.');
        }

        $sesion = Sesion::firstOrCreate(
            [
                'caso_id' => $caso->id,
                'formulario_id' => $formulario->id,
                'usuario_id' => $user->id,
                'completado' => false,
            ]
        );

        $formulario->load('preguntas');
        $sesion->load('respuestas');
        $respuestasPrevias = $sesion->respuestas->keyBy('pregunta_id');

        return view("{$viewFolder}.formularios.show", compact('caso', 'formulario', 'sesion', 'respuestasPrevias'));
    }

    public function showSesion(Sesion $sesion)
    {
        $user = Auth::user();
        $viewFolder = $this->getViewFolder();

         if (!$viewFolder) {
              abort(403, 'Rol no válido.');
         }

        $this->authorize('view', $sesion->caso);
        
        $sesion->load(['formulario.preguntas', 'respuestas', 'caso', 'user']); 
        
        $respuestas = $sesion->respuestas->keyBy('pregunta_id');
        
        return view("{$viewFolder}.sesiones.show", compact('sesion', 'respuestas'));
    }
}