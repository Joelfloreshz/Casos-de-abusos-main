<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Caso;
use App\Models\Formulario;
use App\Models\Sesion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class FormularioController extends Controller
{
    use AuthorizesRequests;

    // Muestra la lista de formularios disponibles para un caso
    public function index(Caso $caso)
    {
        $this->authorize('view', $caso);

        // Busca formularios cuya 'area' sea 'psicologica' o 'ambas'
        $formularios = Formulario::whereIn('area', ['psicologica', 'ambas'])
                                 ->orderBy('nombre')
                                 ->get();

        // Obtiene las sesiones ya completadas para este caso
        $sesionesCompletadas = $caso->sesiones()
                                   ->where('completado', true)
                                   ->with('formulario')
                                   ->get()
                                   ->keyBy('formulario_id');

        return view('psicologa.formularios.index', compact('caso', 'formularios', 'sesionesCompletadas'));
    }

    // Muestra un formulario específico para ser llenado (o crea una nueva sesión si no existe)
    public function show(Caso $caso, Formulario $formulario)
    {
        $this->authorize('view', $caso);

        if (!in_array($formulario->area, ['psicologica', 'ambas'])) {
            abort(403, 'Este formulario no está disponible para esta área.');
        }

        $sesion = $caso->sesiones()
                       ->where('formulario_id', $formulario->id)
                       // ---> CORRECCIÓN AQUÍ TAMBIÉN: Usar usuario_id al buscar <---
                       ->where('usuario_id', Auth::id()) // Asegura buscar sesión del usuario actual
                       ->where('completado', false)
                       ->first();

        // Si no existe una sesión en progreso PARA ESTE USUARIO, crea una nueva
        if (!$sesion) {
             // ---> CORRECCIÓN EN LA LÍNEA ~60: Cambiar user_id por usuario_id <---
            $sesion = $caso->sesiones()->create([
                'formulario_id' => $formulario->id,
                'usuario_id' => Auth::id(), // Columna correcta según error SQL
                'completado' => false,
            ]);
        }

        $sesion->load('formulario.preguntas.respuestas');
        $respuestasPrevias = $sesion->respuestas->keyBy('pregunta_id');

        return view('psicologa.formularios.show', compact('caso', 'formulario', 'sesion', 'respuestasPrevias'));
    }

    // Muestra las respuestas de una sesión ya completada
    public function showSesion(Sesion $sesion)
    {
        $this->authorize('view', $sesion->caso);
        $sesion->load('formulario.preguntas.respuestas', 'caso', 'user'); // 'user' debe coincidir con el nombre de la relación en Sesion.php
        $respuestas = $sesion->respuestas->keyBy('pregunta_id');
        return view('psicologa.sesiones.show', compact('sesion', 'respuestas'));
    }
}