<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Formulario;
use App\Models\Pregunta;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth; 

class PreguntaController extends Controller
{
    private $allowedAreas = ['psicologica', 'ambas'];
    private $routePrefix = 'psicologa.gestion-formularios';

    public function store(Request $request, Formulario $gestion_formulario) 
    {
        if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
             abort(403, 'No puedes añadir preguntas a este formulario.');
        }

        $validated = $request->validate([
            'pregunta' => 'required|string|max:1000',
            'tipo_respuesta' => ['required', 'string', Rule::in(['texto', 'numero', 'si_no', 'multiple'])],
            'numero' => 'required|integer',
            'opciones' => 'nullable|string|required_if:tipo_respuesta,multiple|max:2000',
            'requerida' => 'boolean',
        ]);

        $gestion_formulario->preguntas()->create($request->all());

        return redirect()->route("{$this->routePrefix}.edit", $gestion_formulario)
                         ->with('success_pregunta', 'Pregunta añadida exitosamente.');
    }

    public function edit(Formulario $gestion_formulario, Pregunta $pregunta) 
    {
          if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
               abort(403, 'No tienes permiso para editar preguntas de este formulario.');
         }

        $formulario = $gestion_formulario->load('preguntas'); 
        return view('psicologa.gestion-formularios.edit', compact('formulario', 'pregunta'));
    }
    
    public function update(Request $request, Formulario $gestion_formulario, Pregunta $pregunta) 
    {
         if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
             abort(403, 'No tienes permiso para actualizar preguntas de este formulario.');
        }

        $validated = $request->validate([
            'pregunta' => 'required|string|max:1000',
            'tipo_respuesta' => ['required', 'string', Rule::in(['texto', 'numero', 'si_no', 'multiple'])],
            'numero' => 'required|integer',
            'opciones' => 'nullable|string|required_if:tipo_respuesta,multiple|max:2000',
            'requerida' => 'boolean',
        ]);

        $pregunta->update($request->all());

        return redirect()->route("{$this->routePrefix}.edit", $gestion_formulario)
                         ->with('success_pregunta', 'Pregunta actualizada exitosamente.');
    }

    public function destroy(Formulario $gestion_formulario, Pregunta $pregunta) 
    {
        if (!in_array($gestion_formulario->area, $this->allowedAreas)) {
             abort(403, 'No tienes permiso para eliminar preguntas de este formulario.');
        }
        
        $pregunta->delete();

        return redirect()->route("{$this->routePrefix}.edit", $gestion_formulario)
                         ->with('success_pregunta', 'Pregunta eliminada exitosamente.');
    }
}