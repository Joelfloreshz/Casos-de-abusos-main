<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Formulario;
use App\Models\Pregunta;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth; 

class PreguntaController extends Controller
{

    public function store(Request $request, Formulario $gestion_formulario) 
    {
        
        if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
             abort(403, 'No puedes añadir preguntas a este formulario.');
        }

        $validated = $request->validate([
            'texto' => 'required|string|max:1000',
            'tipo' => ['required', 'string', Rule::in(['texto', 'numero', 'opcion_simple', 'opcion_multiple', 'fecha', 'textarea'])],
            'opciones' => 'nullable|string|required_if:tipo,opcion_simple,opcion_multiple|max:2000',
            'es_obligatoria' => 'boolean',
        ]);

        $orden = ($gestion_formulario->preguntas()->max('orden') ?? 0) + 1;

        $gestion_formulario->preguntas()->create([
            'texto' => $validated['texto'],
            'tipo' => $validated['tipo'],

            'opciones' => in_array($validated['tipo'], ['opcion_simple', 'opcion_multiple']) ? $request->opciones : null,
            'es_obligatoria' => $request->boolean('es_obligatoria'), 
            'orden' => $orden,
        ]);

        return redirect()->route('psicologa.gestion-formularios.edit', $gestion_formulario)
                         ->with('success_pregunta', 'Pregunta añadida exitosamente.');
    }

    public function edit(Formulario $gestion_formulario, Pregunta $pregunta) 
    {
   
          if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
               abort(403, 'No tienes permiso para editar preguntas de este formulario.');
         }

        $formulario = $gestion_formulario->load('preguntas'); 
        return view('psicologa.gestion-formularios.edit', compact('formulario', 'pregunta'));
    }public function update(Request $request, Formulario $gestion_formulario, Pregunta $pregunta) 
    {

         if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
             abort(403, 'No tienes permiso para actualizar preguntas de este formulario.');
        }

        $validated = $request->validate([
            'texto' => 'required|string|max:1000',
            'tipo' => ['required', 'string', Rule::in(['texto', 'numero', 'opcion_simple', 'opcion_multiple', 'fecha', 'textarea'])],
            'opciones' => 'nullable|string|required_if:tipo,opcion_simple,opcion_multiple|max:2000',
            'es_obligatoria' => 'boolean',
        ]);

        $pregunta->update([
             'texto' => $validated['texto'],
             'tipo' => $validated['tipo'],
             'opciones' => in_array($validated['tipo'], ['opcion_simple', 'opcion_multiple']) ? $request->opciones : null,
             'es_obligatoria' => $request->boolean('es_obligatoria'),
        ]);

        return redirect()->route('psicologa.gestion-formularios.edit', $gestion_formulario)
                         ->with('success_pregunta', 'Pregunta actualizada exitosamente.');
    }

    public function destroy(Formulario $gestion_formulario, Pregunta $pregunta) 
    {

        if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
             abort(403, 'No tienes permiso para eliminar preguntas de este formulario.');
        }
        
        $pregunta->delete();

        return redirect()->route('psicologa.gestion-formularios.edit', $gestion_formulario)
                         ->with('success_pregunta', 'Pregunta eliminada exitosamente.');
    }
}