<?php

namespace App\Http\Controllers\Psicologa;

use App\Http\Controllers\Controller;
use App\Models\Formulario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GestionFormularioController extends Controller
{

    public function index(Request $request)
    {
        $query = Formulario::query();

        if ($request->filled('search')) { 
            $query->where('nombre', 'like', '%' . $request->search . '%');
        }

        $formularios = $query->whereIn('area', ['psicologica', 'ambas']) 
                             ->orderBy('created_at', 'desc')
                             ->paginate(10);
        $formularios->loadCount('preguntas');

        return view('psicologa.gestion-formularios.index', compact('formularios'));
    }
    public function create()
    {
        return view('psicologa.gestion-formularios.create');
    }
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:200', 
            'tipo' => 'required|in:ingreso,seguimiento,evaluacion', 
            'area' => 'required|in:psicologica,juridica,ambas', 
        ]);
        if ($validated['area'] === 'juridica') {
             return back()->withErrors(['area' => 'No puedes crear un formulario exclusivo del área jurídica. Selecciona "Psicológica" o "Ambas".'])->withInput();
        }

        $formulario = new Formulario($validated);
        $formulario->creado_por = Auth::id(); 
        $formulario->activo = true; 
        $formulario->save();
        return redirect()->route('psicologa.gestion-formularios.edit', $formulario)
                         ->with('success', 'Formulario creado. Ahora puedes añadir preguntas.');
    }
    public function edit(Formulario $gestion_formulario) 
    {
         if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
             abort(403, 'No tienes permiso para editar este formulario.');
         }
        $formulario = $gestion_formulario->load('preguntas');
        return view('psicologa.gestion-formularios.edit', compact('formulario'));
    }
     public function update(Request $request, Formulario $gestion_formulario)
    {
         if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
             abort(403, 'No tienes permiso para actualizar este formulario.');
         }
        $validated = $request->validate([
            'nombre' => 'required|string|max:200',
            'tipo' => 'required|in:ingreso,seguimiento,evaluacion',
            'area' => 'required|in:psicologica,juridica,ambas',
        ]);
        if ($validated['area'] === 'juridica') {
             return back()->withErrors(['area' => 'No puedes asignar un formulario exclusivamente al área jurídica. Selecciona "Psicológica" o "Ambas".'])->withInput();
        }

        $gestion_formulario->update($validated);

        return redirect()->route('psicologa.gestion-formularios.edit', $gestion_formulario)
                         ->with('success', 'Formulario actualizado exitosamente.');
    }
    public function destroy(Formulario $gestion_formulario) 
    {
         if (!in_array($gestion_formulario->area, ['psicologica', 'ambas'])) {
             abort(403, 'No tienes permiso para eliminar este formulario.');
         }
        $gestion_formulario->delete();

        return redirect()->route('psicologa.gestion-formularios.index')
                         ->with('success', 'Formulario eliminado exitosamente.');
    }

}