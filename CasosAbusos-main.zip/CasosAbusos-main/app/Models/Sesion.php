<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Sesion extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'sesions'; // Nombre de la tabla

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'caso_id',
        'formulario_id',
        // ---> CORRECCIÓN AQUÍ: Cambiar 'user_id' por 'usuario_id' <---
        'usuario_id',
        'completado',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'completado' => 'boolean',
    ];

    /**
     * Get the caso that owns the sesion.
     */
    public function caso(): BelongsTo
    {
        return $this->belongsTo(Caso::class);
    }

    /**
     * Get the formulario that owns the sesion.
     */
    public function formulario(): BelongsTo
    {
        return $this->belongsTo(Formulario::class);
    }

    /**
     * Get the user that created the sesion.
     * Asegúrate que la relación también use 'usuario_id' si es necesario.
     */
    public function user(): BelongsTo
    {
        // Si la columna en la BD es 'usuario_id', especifícala como segundo argumento
        return $this->belongsTo(User::class, 'usuario_id');
    }

    /**
     * Get the respuestas for the sesion.
     */
    public function respuestas(): HasMany
    {
        return $this->hasMany(Respuesta::class);
    }
}