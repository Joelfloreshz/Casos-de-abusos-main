import './bootstrap';

// Importa AlpineJS
import Alpine from 'alpinejs';
window.Alpine = Alpine;

// Inicia Alpine
Alpine.start();