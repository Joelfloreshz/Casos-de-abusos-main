@extends('layouts.abogada')
@section('title', 'Gestionar Formulario: ' . $formulario->nombre)

@section('content')
{{-- Mensajes de Error --}}
@if ($errors->any())
    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded dark:bg-red-900 dark:text-red-200 dark:border-red-700" role="alert">
        <strong class="font-bold">¡Error!</strong> Revisa los campos marcados.
    </div>
@endif
@if (session('success') && !session('success_pregunta'))
    <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg dark:bg-green-800 dark:border-green-600 dark:text-green-200" role="alert">
        {{ session('success') }}
    </div>
@endif

<div class="bg-white dark:bg-gray-800 shadow rounded-lg mb-6">
    {{-- Encabezado --}}
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
        <h2 class="text-xl font-bold text-gray-800 dark:text-gray-100"><i class="fas fa-edit mr-2"></i> Editar Formulario</h2>
         <a href="{{ route('abogada.gestion-formularios.index') }}" class="text-sm text-indigo-600 dark:text-indigo-400 hover:underline flex items-center">
             <i class="fas fa-arrow-left mr-1"></i> Volver al listado
         </a>
    </div>
    {{-- Formulario --}}
    <div class="p-6">
        <form action="{{ route('abogada.gestion-formularios.update', $formulario) }}" method="POST">
            @csrf
            @method('PUT')
            @include('abogada.gestion-formularios._form')
            <div class="flex justify-end mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300">
                    Actualizar Datos
                </button>
            </div>
        </form>
    </div>
</div>
<div class="bg-white dark:bg-gray-800 shadow rounded-lg">
    {{-- Encabezado --}}
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-xl font-bold text-gray-800 dark:text-gray-100"><i class="fas fa-list-ol mr-2"></i> Preguntas del Formulario</h3>
    </div>

    {{-- Sub-bloque: Añadir Nueva Pregunta --}}
    <div class="p-6 border-b border-gray-200 dark:border-gray-700">
        <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Añadir Nueva Pregunta</h4>
         @if (session('success_pregunta'))
            <div class="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded-lg dark:bg-green-800 dark:border-green-600 dark:text-green-200" role="alert">
                {{ session('success_pregunta') }}
            </div>
         @endif
         @if ($errors->any() && !$errors->hasAny(['nombre', 'tipo', 'area']))
            <div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded dark:bg-red-900 dark:text-red-200 dark:border-red-700" role="alert">
                <strong class="font-bold">¡Error al guardar la pregunta!</strong> Revisa los campos marcados abajo.
            </div>
         @endif

        {{-- Formulario Añadir --}}
        <form action="{{ route('abogada.gestion-formularios.preguntas.store', $formulario) }}" method="POST">
            @csrf
            @include('abogada.gestion-formularios._pregunta-form', ['pregunta' => new \App\Models\Pregunta()])
            <div class="flex justify-end mt-4">
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-700 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-600 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300">
                    <i class="fas fa-plus mr-2"></i> Añadir Pregunta
                </button>
            </div>
        </form>
    </div>

    {{-- Sub-bloque: Preguntas Existentes --}}
    <div class="p-6">
        <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Preguntas Existentes</h4>
        <div class="space-y-6">
            @forelse($formulario->preguntas->sortBy('numero') as $pregunta)
                <div class="p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-700/50" x-data="{ open: false }">
                    {{-- Cabecera Pregunta --}}
                    <div class="flex justify-between items-center cursor-pointer" @click="open = !open">
                        <p class="font-medium text-gray-800 dark:text-gray-100">{{ $pregunta->numero }}. {{ Str::limit($pregunta->pregunta, 80) }} @if($pregunta->requerida)<span class="text-red-500">*</span>@endif</p>
                        <i class="fas text-gray-500 dark:text-gray-400 transition-transform" :class="{ 'fa-chevron-down': !open, 'fa-chevron-up': open }"></i>
                    </div>
                    {{-- Contenido Colapsable (Formulario Edición) --}}
                    <div x-show="open" x-collapse style="display: none;" class="mt-4 pt-4 border-t dark:border-gray-600">
                        <form action="{{ route('abogada.gestion-formularios.preguntas.update', [$formulario, $pregunta]) }}" method="POST">
                            @csrf
                            @method('PUT')
                            @include('abogada.gestion-formularios._pregunta-form', ['pregunta' => $pregunta])
                            {{-- Botones Eliminar/Actualizar --}}
                            <div class="flex justify-end items-center space-x-4 mt-4">
                                @if($formulario->creado_por === Auth::id())
                                <form action="{{ route('abogada.gestion-formularios.preguntas.destroy', [$formulario, $pregunta]) }}" method="POST" onsubmit="return confirm('¿Segura que quieres eliminar esta pregunta?');" class="m-0">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-900 focus:outline-none focus:border-red-900 focus:ring ring-red-300">
                                        Eliminar
                                    </button>
                                </form>
                                @endif
                                <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300">
                                    Actualizar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            @empty
                <p class="text-sm text-center text-gray-500 dark:text-gray-400 py-6">
                    Este formulario aún no tiene preguntas.
                </p>
            @endforelse
        </div>
    </div>
</div>
@endsection