@extends('layouts.abogada') 
@section('title', 'Gestión de Formularios')

@section('content')
{{-- Encabezado y botón Nuevo --}}
<div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">Mis Formularios (Jurídico)</h1>
    <a href="{{ route('abogada.gestion-formularios.create') }}" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300 disabled:opacity-25 transition ease-in-out duration-150 flex-shrink-0">
        <i class="fas fa-plus mr-2"></i>
        Nuevo Formulario
    </a>
</div>

{{-- Barra de Búsqueda --}}
<div class="mb-6 bg-white dark:bg-gray-800 shadow rounded-lg p-4">
    <form action="{{ route('abogada.gestion-formularios.index') }}" method="GET">
        <div class="flex items-center">
            <input type="text" name="search" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" placeholder="Buscar por nombre..." value="{{ request('search') }}">
            <button type="submit" class="ml-3 inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700">
                <i class="fas fa-search"></i>
            </button>
             <a href="{{ route('abogada.gestion-formularios.index') }}" class="ml-2 inline-flex items-center px-4 py-2 bg-gray-300 dark:bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-gray-700 dark:text-gray-200 uppercase tracking-widest hover:bg-gray-400 dark:hover:bg-gray-500">
                Limpiar
            </a>
        </div>
    </form>
</div>

{{-- Tabla de Formularios --}}
<div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
            <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nombre</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Tipo / Área</th>
                <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Preguntas</th>
                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Acciones</th>
            </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            @forelse ($formularios as $formulario)
                <tr
                    x-data="{ link: '{{ route('abogada.gestion-formularios.edit', $formulario) }}' }"
                    @click="window.location.href = link"
                    class="hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition duration-150 ease-in-out"
                >
                    {{-- Nombre --}}
                    <td class="px-6 py-4 whitespace-nowrap">
                        {{-- Ya no se necesita el enlace <a> aquí --}}
                        <span class="text-sm font-medium text-indigo-600 dark:text-indigo-400">
                            {{ $formulario->nombre }}
                        </span>
                        {{-- <p class="text-sm text-gray-500 dark:text-gray-400">{{ Str::limit($formulario->descripcion, 70) }}</p> --}}
                    </td>
                    {{-- Tipo / Área --}}
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                       <div>Tipo: {{ ucfirst($formulario->tipo ?? 'N/A') }}</div>
                       <div class="text-xs">Área: {{ ucfirst($formulario->area ?? 'N/A') }}</div>
                    </td>
                    {{-- Conteo de Preguntas --}}
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-center text-gray-600 dark:text-gray-300">{{ $formulario->preguntas_count }}</td>
                    {{-- Acciones --}}
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div class="flex justify-end items-center space-x-3">
                            @if($formulario->creado_por === Auth::id())
                                {{-- Detener la propagación del click para que no active el click de la fila --}}
                                <form @click.stop="" action="{{ route('abogada.gestion-formularios.destroy', $formulario) }}" method="POST" onsubmit="return confirm('¿Estás segura de eliminar este formulario? Se eliminarán todas sus preguntas.');" class="inline-block m-0 p-0">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400 p-1 rounded-md" title="Eliminar Formulario"> {{-- Añadido padding y redondeo --}}
                                        <i class="fas fa-trash fa-fw"></i>
                                    </button>
                                </form>
                            @else
                                <span @click.stop="" class="text-gray-300 dark:text-gray-600 cursor-not-allowed p-1" title="Solo el creador puede eliminar"> {{-- Añadido padding --}}
                                     <i class="fas fa-trash fa-fw"></i>
                                </span>
                            @endif
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                        No se encontraron formularios que coincidan con tu búsqueda o no has creado ninguno.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
    @if ($formularios->hasPages())
        <div class="px-6 py-4 border-t dark:border-gray-700">
            {{ $formularios->links() }}
        </div>
    @endif
</div>
@endsection