@extends('layouts.psicologa') 

    @section('title', 'Respuestas del Formulario: ' . $sesion->formulario->nombre)

    @section('content')
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg max-w-3xl mx-auto">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 class="text-xl font-bold text-gray-800 dark:text-gray-100">{{ $sesion->formulario->nombre ?? 'Formulario Desconocido' }}</h2>
            <div class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                <p>
                    <strong>Caso:</strong>
                   
                    <a href="{{ route('psicologa.casos.show', $sesion->caso) }}" class="text-blue-600 dark:text-blue-400 hover:underline">
                        {{ $sesion->caso->codigo_caso ?? 'Caso Desconocido' }}
                    </a> - {{ $sesion->caso->nombre_afectada ?? 'Afectada Desconocida' }}
                </p>
                <p><strong>Fecha de Sesión:</strong> {{ $sesion->created_at ? $sesion->created_at->isoFormat('dddd, D [de] MMMM [de] YYYY, h:mm A') : 'N/A' }}</p>
                <p><strong>Registrado por:</strong> {{ $sesion->user->nombre ?? 'Usuario desconocido' }}</p>
            </div>
        </div>
        <div class="divide-y divide-gray-200 dark:divide-gray-700">
            @forelse($sesion->formulario->preguntas->sortBy('numero') as $pregunta)
                @php
                   
                    $respuesta = $sesion->respuestas->firstWhere('pregunta_id', $pregunta->id);
                @endphp
                <div class="px-6 py-4">
                    <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                        {{ $pregunta->numero ?? '?' }}. {{ $pregunta->pregunta ?? 'Pregunta eliminada' }}
                        @if($pregunta->requerida ?? false) <span class="text-red-500 text-xs">*</span> @endif
                    </p>
                    <div class="mt-2 text-sm text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 p-3 rounded-md border border-gray-200 dark:border-gray-600 whitespace-pre-wrap">
                     
                        {{ $respuesta->respuesta ?? 'No contestada' }}
                    </div>
                </div>
            @empty
                <div class="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                    Este formulario no tiene preguntas definidas o las preguntas fueron eliminadas.
                </div>
            @endforelse
        </div>
        <div class="px-6 py-4 bg-gray-50 dark:bg-gray-700 flex justify-end">
          
            <a href="{{ route('psicologa.casos.show', $sesion->caso) }}" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150">
                Volver al Caso
            </a>
        </div>
    </div>
    @endsection