@extends('layouts.psicologa') 
@section('title', 'Detalle del Caso Psicológico: ' . $caso->codigo_caso)

@section('content')

    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                 
                <h2 class="text-2xl font-bold text-gray-800 dark:text-gray-100"><i class="fas fa-user-md mr-2"></i> {{ $caso->codigo_caso }}</h2>
                <p class="text-sm text-gray-600 dark:text-gray-400">{{ $caso->nombre_afectada }}</p>
                <p class="text-sm font-medium text-blue-600 dark:text-blue-400 mt-1">
                    <i class="fas fa-project-diagram fa-fw mr-1"></i>
                    {{ $caso->proyecto->nombre ?? 'Sin proyecto asignado' }}
                </p>
            </div>
            <div class="flex-shrink-0 flex gap-2">
                @can('update', $caso)
                <a href="{{ route('psicologa.casos.edit', $caso) }}" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    <i class="fas fa-edit mr-1.5"></i> Editar
                </a>
                @endcan
                @if($caso->estado != 'cerrado')
                    <a href="{{ route('psicologa.formularios.index', $caso) }}" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <i class="fas fa-file-alt mr-1.5"></i> Iniciar Formulario
                    </a>
                @endif
            </div>
        </div>
        <div class="px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Datos de la Afectada</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 text-sm">
                <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">DUI:</strong> {{ $caso->dui ?? 'No especificado' }}</p>
                <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Ubicación:</strong> {{ $caso->municipio ?? 'N/A' }}, {{ $caso->departamento ?? 'N/A' }}</p>
                <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Edad:</strong> {{ $caso->edad ?? 'No especificada' }}</p>
                 <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Zona:</strong> {{ ucfirst($caso->zona ?? 'N/E') }}</p>
                <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Fecha de Ingreso:</strong> {{ $caso->fecha_ingreso ? $caso->fecha_ingreso->format('d/m/Y') : 'N/A' }}</p>
                <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Teléfono:</strong> {{ $caso->telefono ?? 'No especificado' }}</p>
                <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Estado:</strong>

                    <span @class([
                        'ml-1 px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full',
                        'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-200' => $caso->estado == 'activo',
                        'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-200' => $caso->estado == 'en_evaluacion', 
                        'bg-purple-100 text-purple-800 dark:bg-purple-800 dark:text-purple-200' => $caso->estado == 'en_terapia', 
                        'bg-orange-100 text-orange-800 dark:bg-orange-800 dark:text-orange-200' => $caso->estado == 'seguimiento_externo', 
                        'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-200' => $caso->estado == 'En Juicio', 
                        'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' => $caso->estado == 'cerrado',
                        'bg-gray-200 text-gray-600' => !$caso->estado
                    ])>
                         {{ match($caso->estado) {
                            'activo' => 'Activo',
                            'en_evaluacion' => 'Evaluación', 
                            'en_terapia' => 'Terapia', 
                            'seguimiento_externo' => 'Seg. Externo', 
                            'En Juicio' => 'En Juicio', 
                            'cerrado' => 'Cerrado',
                            default => ucfirst(str_replace('_', ' ', $caso->estado ?? 'N/A'))
                         } }}
                    </span>
                </p>
                <p class="md:col-span-2 text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Motivo de Consulta:</strong> {{ $caso->motivo }}</p>
            </div>

            @if($caso->nombre_agresor || $caso->parentesco_agresor || $caso->estado_civil_agresor || $caso->ocupacion_agresor)
            <div class="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                 <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Datos del Agresor</h3>
                 <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 text-sm">
                    <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Nombre:</strong> {{ $caso->nombre_agresor ?? 'No especificado' }}</p>
                    <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Parentesco:</strong> {{ $caso->parentesco_agresor ?? 'No especificado' }}</p>
                    <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Estado Civil:</strong> {{ $caso->estado_civil_agresor ?? 'No especificado' }}</p>
                    <p class="text-gray-700 dark:text-gray-300"><strong class="font-semibold text-gray-800 dark:text-gray-100">Ocupación:</strong> {{ $caso->ocupacion_agresor ?? 'No especificado' }}</p>
                 </div>
            </div>
            @endif
        </div>
    </div>
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            
            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex items-center">
                <i class="fas fa-notes-medical mr-3"></i> Bitácora / Historial de Sesiones
            </h3>
           
            @if($caso->estado != 'cerrado')
                <button id="toggle-seguimiento-form" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <i class="fas fa-plus"></i> Añadir Sesión/Seg.
                </button>
            @endif
        </div>

        
        <div id="form-seguimiento-container" style="display: none;" class="px-6 py-4 border-b border-dashed border-gray-300 dark:border-gray-600">
             @if($caso->estado != 'cerrado')
                <form action="{{ route('psicologa.casos.seguimientos.store', $caso) }}" method="POST">
                    @csrf
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label for="fecha" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Fecha</label>
                            <input type="date" id="fecha" name="fecha" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" value="{{ date('Y-m-d') }}" required>
                        </div>
                        <div>
                             <label for="tipo_actuacion" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipo Sesión/Actuación</label>
                             <select id="tipo_actuacion" name="tipo_actuacion" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm">
                                 <option value="">Seleccione...</option>
                                 
                                 <option value="Evaluación Inicial">Evaluación Inicial</option>
                                 <option value="Sesión Terapia Individual">Sesión Terapia Individual</option>
                                 <option value="Sesión Terapia Grupal">Sesión Terapia Grupal</option>
                                 <option value="Visita Domiciliaria">Visita Domiciliaria</option>
                                 <option value="Llamada Seguimiento">Llamada Seguimiento</option>
                                 <option value="Interconsulta">Interconsulta</option>
                                 <option value="Coordinación Externa">Coordinación Externa</option>
                                 <option value="Otro">Otro</option>
                             </select>
                        </div>
                        <div>
                            <label for="proxima_cita" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Próxima Sesión (Opcional)</label>
                            <input type="date" id="proxima_cita" name="proxima_cita" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm">
                        </div>
                    </div>
                    <div>
                        <label for="descripcion" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Descripción / Notas de Sesión</label>
                        <textarea id="descripcion" name="descripcion" rows="4" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" required placeholder="Describe aquí los detalles de la sesión, avances, observaciones..."></textarea>
                    </div>
                    <div class="text-right mt-4">
                        
                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150">
                            Guardar Seguimiento
                        </button>
                    </div>
                </form>
             @else
                <p class="text-sm text-center text-gray-500 dark:text-gray-400">Este caso está cerrado y no se pueden añadir nuevas sesiones/seguimientos.</p>
            @endif
        </div>

        <div class="p-6 space-y-6">
            @forelse($caso->seguimientos->sortByDesc('fecha') as $seguimiento)
                <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow border border-gray-200 dark:border-gray-600 relative group">
                    
                    <div class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        
                        <form action="{{ route('psicologa.seguimientos.destroy', $seguimiento) }}" method="POST" onsubmit="return confirm('¿Confirmas que quieres eliminar este seguimiento?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="inline-flex items-center justify-center h-6 w-6 rounded-full text-xs text-white bg-red-500 hover:bg-red-700 focus:outline-none">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </div>

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2 pb-2 border-b border-gray-300 dark:border-gray-500">
                        <h4 class="text-base font-semibold text-gray-800 dark:text-gray-100 flex items-center">
                          
                            @php
                                $icon = match($seguimiento->tipo_actuacion ?? '') {
                                    'Evaluación Inicial' => 'fa-clipboard-list',
                                    'Sesión Terapia Individual' => 'fa-user',
                                    'Sesión Terapia Grupal' => 'fa-users',
                                    'Visita Domiciliaria' => 'fa-home',
                                    'Llamada Seguimiento' => 'fa-phone-alt',
                                    'Interconsulta' => 'fa-exchange-alt',
                                    'Coordinación Externa' => 'fa-sitemap',
                                    default => 'fa-notes-medical' 
                                };
                            @endphp
                            <i class="fas {{ $icon }} fa-fw mr-2 text-blue-500 dark:text-blue-400"></i>
                            {{ $seguimiento->tipo_actuacion ?? 'Seguimiento' }}
                        </h4>
                        <span class="text-sm text-gray-600 dark:text-gray-400 mt-1 sm:mt-0">
                            {{ $seguimiento->fecha ? $seguimiento->fecha->isoFormat('dddd, D [de] MMMM, YYYY') : 'Fecha N/A' }}
                        </span>
                    </div>

                    
                    <p class="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap mb-2">{{ $seguimiento->descripcion }}</p>

                    
                    @if($seguimiento->proxima_cita)
                        <p class="text-sm font-semibold text-green-600 dark:text-green-400 border-t border-gray-300 dark:border-gray-500 pt-2 mt-2">
                            <i class="fas fa-calendar-check fa-fw mr-1.5"></i> Próxima Sesión: {{ $seguimiento->proxima_cita->isoFormat('dddd, D [de] MMMM') }}
                        </p>
                    @endif

                     <p class="text-xs text-gray-500 dark:text-gray-400 text-right mt-2">Registrado por: {{ $seguimiento->usuario->nombre ?? 'N/A' }}</p>

                </div>
            @empty
                <p class="text-sm text-center text-gray-500 dark:text-gray-400 py-4">No hay sesiones/seguimientos registrados para este caso.</p>
            @endforelse
        </div>
    </div>
    
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex items-center">
                <i class="fas fa-tasks mr-3"></i> Formularios Completados
            </h3>
        </div>
        <div class="divide-y divide-gray-200 dark:divide-gray-700">
            @forelse($caso->sesiones->where('completado', true) as $sesion)
                <div class="px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                        <span class="font-semibold text-gray-800 dark:text-gray-100">{{ $sesion->formulario->nombre ?? 'Formulario Desconocido' }}</span>
                        <span class="text-sm text-gray-600 dark:text-gray-400">- Completado el {{ $sesion->updated_at ? $sesion->updated_at->format('d/m/Y') : 'N/A' }}</span>
                    </div>
                    
                    <a href="{{ route('psicologa.sesiones.show', $sesion) }}" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                        Ver Respuestas
                    </a>
                </div>
            @empty
                <p class="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">No se ha completado ningún formulario para este caso.</p>
            @endforelse
        </div>
    </div>


@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const toggleButton = document.getElementById('toggle-seguimiento-form');
        const formContainer = document.getElementById('form-seguimiento-container');

        if (toggleButton) {
            toggleButton.addEventListener('click', function() {
                if (formContainer.style.display === 'none' || formContainer.style.display === '') {
                    formContainer.style.display = 'block';
                    toggleButton.innerHTML = '<i class="fas fa-minus"></i>';
                } else {
                    formContainer.style.display = 'none';
                    toggleButton.innerHTML = '<i class="fas fa-plus"></i> Añadir Sesión/Seg.'; 
                }
            });
        }
    });
</script>
@endpush