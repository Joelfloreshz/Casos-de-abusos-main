@extends('layouts.psicologa')

@section('title', 'Formularios del Caso: ' . $caso->codigo_caso)

@section('content')
<div class="mb-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
            <a href="{{ route('psicologa.casos.show', $caso) }}" class="text-sm text-blue-600 dark:text-blue-400 hover:underline mb-2 block">
                <i class="fas fa-arrow-left mr-1"></i> Volver al Caso {{ $caso->codigo_caso }}
            </a>
            <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">Formularios Disponibles</h1>
            <p class="text-lg text-gray-600 dark:text-gray-400">Afectada: {{ $caso->nombre_afectada }}</p>
        </div>
    </div>
</div>

<div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
    <div class="divide-y divide-gray-200 dark:divide-gray-700">
        @forelse($formularios as $formulario)
            @php
                $sesionCompletada = $sesionesCompletadas->get($formulario->id);
            @endphp
            <div class="px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100">{{ $formulario->nombre }}</h3>
                    <p class="text-sm text-gray-600 dark:text-gray-400">{{ $formulario->descripcion }}</p>
                </div>
                <div class="flex-shrink-0 flex gap-2">
                        <a href="{{ route('psicologa.formularios.show', [$caso, $formulario]) }}" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
                            <i class="fas fa-play mr-1.5"></i> Iniciar
                        </a>
                </div>
            </div>
        @empty
            <p class="px-6 py-4 text-sm text-center text-gray-500 dark:text-gray-400">
                No hay formularios psicológicos disponibles o creados.
            </p>
        @endforelse
    </div>
</div>
@endsection