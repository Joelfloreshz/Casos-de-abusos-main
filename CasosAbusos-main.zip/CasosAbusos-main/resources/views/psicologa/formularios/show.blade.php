@extends('layouts.psicologa') 

@section('title', 'Llenando Formulario: ' . $formulario->nombre)

{{-- Añadido enlace para Volver --}}
@section('content')
    <div class="mb-4">
        <a href="{{ route('psicologa.formularios.index', $caso) }}" class="text-sm text-blue-600 dark:text-blue-400 hover:underline flex items-center">
            <i class="fas fa-arrow-left mr-1"></i> Volver a Seleccionar Formulario
        </a>
    </div>

    {{-- ---> CLASES CORREGIDAS AQUÍ: Se quitó 'max-w-3xl mx-auto' <--- --}}
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg w-full"> {{-- Contenedor a ancho completo --}}
        
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 class="text-xl font-bold text-gray-800 dark:text-gray-100">{{ $formulario->nombre }}</h2>
            <p class="text-sm text-gray-600 dark:text-gray-400"><strong>Caso:</strong> {{ $caso->codigo_caso }} - {{ $caso->nombre_afectada }}</p>
        </div>
        
        {{-- Formulario de Respuestas --}}
        <form action="{{ route('psicologa.respuestas.store', $sesion) }}" method="POST">
            @csrf
            <div class="p-6 space-y-6">
                @php
                    $respuestasPrevias = $sesion->respuestas->keyBy('pregunta_id');
                @endphp

                @foreach($formulario->preguntas->sortBy('numero') as $pregunta)
                    @php
                        // Obtener el valor guardado o el valor 'old' si falló la validación
                        $respuestaGuardada = $respuestasPrevias->get($pregunta->id);
                        // Aseguramos que $valor sea un string o array, no nulo
                        $valor = old('respuestas.' . $pregunta->id, $respuestaGuardada->respuesta ?? null);
                         // Decodificar JSON para opción múltiple si es un string
                        $valoresMultiples = $valor;
                        if (is_string($valor) && ($pregunta->tipo_respuesta === 'opcion_multiple' || $pregunta->tipo === 'opcion_multiple')) {
                             $decoded = json_decode($valor, true);
                             if (json_last_error() === JSON_ERROR_NONE) {
                                 $valoresMultiples = $decoded;
                             } else {
                                 $valoresMultiples = (array) $valor; // Fallback por si no es JSON
                             }
                        }
                        if (!is_array($valoresMultiples)) {
                            $valoresMultiples = (array) $valoresMultiples;
                        }
                    @endphp
                    <div>
                        <label for="pregunta-{{ $pregunta->id }}" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            {{ $pregunta->numero ?? $loop->iteration }}. {{ $pregunta->pregunta ?? $pregunta->texto }}
                            @if($pregunta->requerida ?? $pregunta->es_obligatoria) <span class="text-red-500">*</span> @endif
                        </label>
                        @switch($pregunta->tipo_respuesta ?? $pregunta->tipo)
                            @case('texto')
                            @case('textarea')
                                <textarea name="respuestas[{{ $pregunta->id }}]" id="pregunta-{{ $pregunta->id }}" rows="4" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" @if($pregunta->requerida ?? $pregunta->es_obligatoria) required @endif>{{ $valor }}</textarea>
                                @break
                            @case('corta')
                                <input type="text" name="respuestas[{{ $pregunta->id }}]" id="pregunta-{{ $pregunta->id }}" value="{{ $valor }}" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" @if($pregunta->requerida ?? $pregunta->es_obligatoria) required @endif>
                                @break
                            @case('numero')
                                <input type="number" name="respuestas[{{ $pregunta->id }}]" id="pregunta-{{ $pregunta->id }}" value="{{ $valor }}" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" @if($pregunta->requerida ?? $pregunta->es_obligatoria) required @endif>
                                @break
                            @case('fecha') {{-- Añadido tipo fecha --}}
                                 <input type="date" name="respuestas[{{ $pregunta->id }}]" id="pregunta-{{ $pregunta->id }}" value="{{ $valor }}" class="mt-1 block rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" @if($pregunta->requerida ?? $pregunta->es_obligatoria) required @endif>
                                @break
                            @case('si_no')
                                <select name="respuestas[{{ $pregunta->id }}]" id="pregunta-{{ $pregunta->id }}" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" @if($pregunta->requerida ?? $pregunta->es_obligatoria) required @endif>
                                    <option value="" @selected($valor === null || $valor === '')>Seleccione...</option>
                                    <option value="Sí" @selected($valor == 'Sí')>Sí</option>
                                    <option value="No" @selected($valor == 'No')>No</option>
                                </select>
                                @break
                            @case('multiple')
                            @case('opcion_simple')
                                <select name="respuestas[{{ $pregunta->id }}]" id="pregunta-{{ $pregunta->id }}" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm" @if($pregunta->requerida ?? $pregunta->es_obligatoria) required @endif>
                                    <option value="" @selected($valor === null || $valor === '')>Seleccione...</option>
                                    @foreach(explode(',', $pregunta->opciones ?? '') as $opcion)
                                        @php $opcionLimpia = trim($opcion); @endphp
                                        @if($opcionLimpia)
                                            <option value="{{ $opcionLimpia }}" @selected($valor == $opcionLimpia)>{{ $opcionLimpia }}</option>
                                        @endif
                                    @endforeach
                                </select>
                                @break
                            @case('opcion_multiple')
                                @foreach(explode(',', $pregunta->opciones ?? '') as $opcion)
                                     @php $opcionLimpia = trim($opcion); @endphp
                                     @if($opcionLimpia)
                                    <label class="flex items-center text-gray-700 dark:text-gray-300">
                                        <input type="checkbox" name="respuestas[{{ $pregunta->id }}][]" value="{{ $opcionLimpia }}" @checked(in_array($opcionLimpia, $valoresMultiples)) class="h-4 w-4 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 dark:bg-gray-700">
                                        <span class="ml-3">{{ $opcionLimpia }}</span>
                                    </label>
                                    @endif
                                @endforeach
                                @break
                        @endswitch
                        @error('respuestas.' . $pregunta->id)
                            <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                @endforeach
            </div>

            {{-- Botones de Acción (Replicando diseño de Abogada) --}}
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-700/50 flex justify-between items-center">
                
                {{-- Botón Volver --}}
                <a href="{{ route('psicologa.formularios.index', $caso) }}" class="inline-flex items-center px-4 py-2 bg-gray-300 dark:bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-gray-700 dark:text-gray-200 uppercase tracking-widest hover:bg-gray-400 dark:hover:bg-gray-500">
                    <i class="fas fa-arrow-left mr-2"></i> Volver
                </a>
                
                <div class="flex space-x-3">
                
                    {{-- Botón Completar--}}
                    <button type="submit" name="action" value="completar" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300">
                        Completar Formulario
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection