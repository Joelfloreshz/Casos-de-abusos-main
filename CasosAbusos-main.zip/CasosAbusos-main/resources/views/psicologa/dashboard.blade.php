@extends('layouts.psicologa')

@section('title', 'Dashboard Psicología')

@section('content')
<div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-green-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M5 6h14M5 10h14M5 14h14M5 18h14" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                                Casos Activos
                            </dt>
                            <dd class="text-3xl font-semibold text-gray-900 dark:text-gray-100">
                                {{ $casosActivosCount }}
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="{{ route('psicologa.casos.index', ['estado' => 'activo']) }}" class="font-medium text-green-600 dark:text-green-400 hover:text-green-500">
                        Ver todos <span class="sr-only">Casos Activos</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-blue-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                                En Evaluación
                            </dt>
                            <dd class="text-3xl font-semibold text-gray-900 dark:text-gray-100">
                                {{ $casosEnEvaluacionCount }}
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="{{ route('psicologa.casos.index', ['estado' => 'en_evaluacion']) }}" class="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500">
                        Ver todos <span class="sr-only">Casos En Evaluación</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-purple-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1.5a4 4 0 014-4h2a4 4 0 014 4V21M15 21v-1.5a4 4 0 00-4-4H9a4 4 0 00-4 4V21m12 0v-1.5a4 4 0 00-4-4h-2a4 4 0 00-4 4V21m16-12a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                                En Terapia
                            </dt>
                            <dd class="text-3xl font-semibold text-gray-900 dark:text-gray-100">
                                {{ $casosEnTerapiaCount }}
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="{{ route('psicologa.casos.index', ['estado' => 'en_terapia']) }}" class="font-medium text-purple-600 dark:text-purple-400 hover:text-purple-500">
                        Ver todos <span class="sr-only">Casos En Terapia</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                                Seguimiento Externo
                            </dt>
                            <dd class="text-3xl font-semibold text-gray-900 dark:text-gray-100">
                                {{ $casosSeguimientoExternoCount }}
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="{{ route('psicologa.casos.index', ['estado' => 'seguimiento_externo']) }}" class="font-medium text-yellow-600 dark:text-yellow-400 hover:text-yellow-500">
                        Ver todos <span class="sr-only">Casos Seguimiento Externo</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-red-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                                Casos Cerrados
                            </dt>
                            <dd class="text-3xl font-semibold text-gray-900 dark:text-gray-100">
                                {{ $casosCerradosCount }}
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="{{ route('psicologa.casos.index', ['estado' => 'cerrado']) }}" class="font-medium text-red-600 dark:text-red-400 hover:text-red-500">
                        Ver todos <span class="sr-only">Casos Cerrados</span>
                    </a>
                </div>
            </div>
        </div>

    </div>

    <div class="mt-8 bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div class="px-4 py-5 sm:px-6">
            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100">
                Próximas Sesiones / Citas
            </h3>
            <p class="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
                Citas programadas para casos no cerrados.
            </p>
        </div>
        <div class="border-t border-gray-200 dark:border-gray-700">
            <ul class="divide-y divide-gray-200 dark:divide-gray-700">
                @forelse($proximasCitas as $cita)
                    <li class="p-4 hover:bg-gray-50 dark:hover:bg-gray-700">
                        <a href="{{ route('psicologa.casos.show', $cita->caso) }}" class="block">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-medium text-blue-600 dark:text-blue-400 truncate">
                                    {{ $cita->caso->nombre_afectada }}
                                </p>
                                <p class="text-sm text-gray-600 dark:text-gray-400">
                                    {{ $cita->proxima_cita->isoFormat('dddd, D [de] MMMM') }}
                                </p>
                            </div>
                            <div class="mt-2 sm:flex sm:justify-between">
                                <div class="sm:flex">
                                    <p class="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                        {{ $cita->caso->codigo_caso }}
                                    </p>
                                </div>
                                <div class="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 sm:mt-0">
                                    <p>
                                        {{ $cita->descripcion }}
                                    </p>
                                </div>
                            </div>
                        </a>
                    </li>
                @empty
                    <li class="p-4 text-center text-sm text-gray-500 dark:text-gray-400">
                        No hay próximas citas registradas.
                    </li>
                @endforelse
            </ul>
        </div>
    </div>

</div>
@endsection