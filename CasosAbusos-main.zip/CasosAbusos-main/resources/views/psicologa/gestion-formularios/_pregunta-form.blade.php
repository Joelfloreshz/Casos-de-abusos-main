{{-- Este formulario parcial se usa en edit.blade.php (dentro del AlpineJS) --}}
{{-- Utiliza la variable formData de AlpineJS para los valores --}}
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    {{-- Texto de la Pregunta --}}
    <div class="md:col-span-2">
        <label for="texto" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Texto de la Pregunta</label>
        <textarea id="texto" name="texto" rows="3" x-model="formData.texto"
                  class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm @error('texto') border-red-500 @enderror" required></textarea>
        @error('texto') <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p> @enderror
    </div>

    {{-- Tipo de Respuesta --}}
    <div>
        <label for="tipo" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipo de Respuesta</label>
        <select id="tipo" name="tipo" x-model="formData.tipo"
                class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm @error('tipo') border-red-500 @enderror">
            <option value="texto">Texto Corto</option>
            <option value="textarea">Párrafo (Texto Largo)</option>
            <option value="numero">Número</option>
            <option value="fecha">Fecha</option>
            <option value="opcion_simple">Opción Simple (Radio)</option>
            <option value="opcion_multiple">Opción Múltiple (Checkbox)</option>
        </select>
        @error('tipo') <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p> @enderror
    </div>

    {{-- Opciones (solo visible para opción simple/múltiple) --}}
    <div x-show="formData.tipo === 'opcion_simple' || formData.tipo === 'opcion_multiple'">
        <label for="opciones" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Opciones (separadas por comas)</label>
        <input type="text" id="opciones" name="opciones" x-model="formData.opciones"
               class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm @error('opciones') border-red-500 @enderror"
               placeholder="Opción 1, Opción 2, Opción 3"
               :required="formData.tipo === 'opcion_simple' || formData.tipo === 'opcion_multiple'">
         @error('opciones') <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p> @enderror
    </div>

    {{-- Checkbox Obligatoria --}}
    <div class="md:col-span-2 flex items-center pt-2">
        <input id="es_obligatoria" name="es_obligatoria" type="checkbox" value="1" x-model="formData.es_obligatoria"
               class="h-4 w-4 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 dark:bg-gray-700 dark:checked:bg-blue-600 dark:focus:ring-offset-gray-800">
        <label for="es_obligatoria" class="ml-2 block text-sm text-gray-900 dark:text-gray-200">Esta pregunta es obligatoria</label>
    </div>
</div>