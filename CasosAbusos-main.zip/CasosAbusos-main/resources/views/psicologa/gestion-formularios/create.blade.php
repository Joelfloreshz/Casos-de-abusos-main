@extends('layouts.psicologa')

@section('title', 'Crear Nuevo Formulario')

@section('content')
<div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6 max-w-4xl mx-auto">
    <h2 class="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-6">
        Crear Nuevo Formulario (Psicología)
    </h2>

    @if ($errors->any())
        <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded dark:bg-red-900 dark:text-red-200 dark:border-red-700" role="alert">
            <strong class="font-bold">¡Error!</strong> Revisa los campos marcados.
            <ul class="list-disc list-inside mt-2">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('psicologa.gestion-formularios.store') }}" method="POST">
        @csrf

        {{-- Incluye el formulario parcial --}}
        @include('psicologa.gestion-formularios._form', ['formulario' => new \App\Models\Formulario()])

        {{-- Botones --}}
        <div class="flex justify-end items-center space-x-4 mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
            <a href="{{ route('psicologa.gestion-formularios.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-300 dark:bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-gray-700 dark:text-gray-200 uppercase tracking-widest hover:bg-gray-400 dark:hover:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition ease-in-out duration-150">
                Cancelar
            </a>
            <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150">
                Crear y Añadir Preguntas
            </button>
        </div>
    </form>
</div>
@endsection