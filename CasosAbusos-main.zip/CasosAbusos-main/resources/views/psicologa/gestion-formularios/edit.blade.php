@extends('layouts.psicologa') {{-- Usa el layout corregido de psicóloga --}}
@section('title', 'Gestionar Formulario: ' . $formulario->nombre)

@section('content')

@if ($errors->any())
    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded dark:bg-red-900 dark:text-red-200 dark:border-red-700" role="alert">
        <strong class="font-bold">¡Error!</strong> Revisa los campos marcados.
        
    </div>
@endif

{{-- Sección Editar Datos del Formulario --}}
<div class="bg-white dark:bg-gray-800 shadow rounded-lg max-w-4xl mx-auto mb-6">
   
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
        <h2 class="text-xl font-bold text-gray-800 dark:text-gray-100"><i class="fas fa-edit mr-2"></i> Editar Formulario</h2>
         <a href="{{ route('psicologa.gestion-formularios.index') }}" class="text-sm text-blue-600 dark:text-blue-400 hover:underline"><i class="fas fa-arrow-left mr-1"></i> Volver al listado</a>
    </div>
    {{-- Contenido del Formulario de Edición --}}
    <div class="p-6">
        <form action="{{ route('psicologa.gestion-formularios.update', $formulario) }}" method="POST">
            @csrf
            @method('PUT')
            
            @include('psicologa.gestion-formularios._form')

            {{-- Botón Actualizar Datos --}}
            <div class="flex justify-end mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150">
                    Actualizar Datos
                </button>
            </div>
        </form>
    </div>
</div>

{{-- Sección Preguntas del Formulario --}}
<div class="bg-white dark:bg-gray-800 shadow rounded-lg max-w-4xl mx-auto">
    {{-- Encabezado del Card de Preguntas --}}
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-xl font-bold text-gray-800 dark:text-gray-100"><i class="fas fa-list-ol mr-2"></i> Preguntas del Formulario</h3>
    </div>

    {{-- Subsección Añadir Nueva Pregunta --}}
    <div class="p-6 border-b border-gray-200 dark:border-gray-700">
        <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Añadir Nueva Pregunta</h4>
        
         @if (session('success_pregunta'))
            <div class="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded-lg dark:bg-green-800 dark:border-green-600 dark:text-green-200" role="alert">
                {{ session('success_pregunta') }}
            </div>
        @endif
         @if ($errors->any() && !$errors->has('nombre') && !$errors->has('tipo') && !$errors->has('area'))
            <div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded dark:bg-red-900 dark:text-red-200 dark:border-red-700" role="alert">
                <strong class="font-bold">¡Error al guardar la pregunta!</strong> Revisa los campos marcados.
            </div>
        @endif
        <form action="{{ route('psicologa.gestion-formularios.preguntas.store', $formulario) }}" method="POST">
            @csrf
           
            @include('psicologa.gestion-formularios._pregunta-form', ['pregunta' => new \App\Models\Pregunta()])

            
            <div class="flex justify-end mt-4">
               
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-700 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-600 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                    <i class="fas fa-plus mr-2"></i> Añadir Pregunta
                </button>
            </div>
        </form>
    </div>

    {{-- Subsección Preguntas Existentes (Colapsables) --}}
    <div class="p-6">
        <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Preguntas Existentes</h4>
        <div class="space-y-6">
            @forelse($formulario->preguntas->sortBy('numero') as $pregunta)

                <div class="p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-700/50" x-data="{ open: false }">

                    <div class="flex justify-between items-center cursor-pointer" @click="open = !open">
                        <p class="font-medium text-gray-800 dark:text-gray-100">{{ $pregunta->numero }}. {{ Str::limit($pregunta->pregunta, 80) }} {{ $pregunta->requerida ? '*' : '' }}</p>
                        <i class="fas text-gray-500 dark:text-gray-400" :class="{ 'fa-chevron-down': !open, 'fa-chevron-up': open }"></i>
                    </div>

                    <div x-show="open" x-collapse class="mt-4 pt-4 border-t dark:border-gray-600">
                        {{-- El formulario apunta a la ruta update de la pregunta específica --}}
                        <form action="{{ route('psicologa.gestion-formularios.preguntas.update', [$formulario, $pregunta]) }}" method="POST">
                            @csrf
                            @method('PUT')

                            @include('psicologa.gestion-formularios._pregunta-form', ['pregunta' => $pregunta])
                            <div class="flex justify-end items-center space-x-4 mt-4">
                            
                                <form action="{{ route('psicologa.gestion-formularios.preguntas.destroy', [$formulario, $pregunta]) }}" method="POST" onsubmit="return confirm('¿Segura que quieres eliminar esta pregunta?');" class="m-0">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-900 focus:outline-none focus:border-red-900 focus:ring ring-red-300 disabled:opacity-25 transition ease-in-out duration-150">
                                        Eliminar
                                    </button>
                                </form>
                               
                                <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150">
                                    Actualizar
                                </button>
                            </div>
                        </form> 
                    </div> 
                </div> 
            @empty
                <p class="text-sm text-center text-gray-500 dark:text-gray-400 py-6">
                    Este formulario aún no tiene preguntas.
                </p>
            @endforelse
        </div>
    </div>
</div>
@endsection