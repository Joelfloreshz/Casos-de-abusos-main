
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    {{-- Nombre del Formulario --}}
    <div>
        <label for="nombre" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nombre del Formulario</label>
        <input type="text" id="nombre" name="nombre" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm @error('nombre') border-red-500 @enderror" value="{{ old('nombre', $formulario->nombre ?? '') }}" required>
        @error('nombre') <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p> @enderror
    </div>

    {{-- Tipo de Formulario (Ingreso, Seguimiento, etc.) --}}
    <div>
        <label for="tipo" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipo</label>
        <select id="tipo" name="tipo" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm @error('tipo') border-red-500 @enderror" required>
            <option value="">Seleccione...</option>
            <option value="ingreso" @selected(old('tipo', $formulario->tipo ?? '') == 'ingreso')>Ingreso</option>
            <option value="seguimiento" @selected(old('tipo', $formulario->tipo ?? '') == 'seguimiento')>Seguimiento</option>
            <option value="evaluacion" @selected(old('tipo', $formulario->tipo ?? '') == 'evaluacion')>Evaluación</option>
            {{-- Añade más tipos si es necesario --}}
        </select>
         @error('tipo') <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p> @enderror
    </div>

    {{-- Área (Psicológica, Jurídica, Ambas) --}}
    <div class="md:col-span-2">
        <label for="area" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Área de Aplicación</label>
        <select id="area" name="area" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm @error('area') border-red-500 @enderror" required>
            <option value="">Seleccione...</option>
            {{-- Psicóloga solo puede seleccionar 'psicologica' o 'ambas' --}}
            <option value="psicologica" @selected(old('area', $formulario->area ?? 'psicologica') == 'psicologica')>Psicológica</option>
            <option value="ambas" @selected(old('area', $formulario->area ?? '') == 'ambas')>Ambas</option>
            {{-- <option value="juridica" @selected(old('area', $formulario->area ?? '') == 'juridica')>Jurídica</option> --}} {{-- Oculta para psicóloga --}}
        </select>
         @error('area') <p class="mt-1 text-xs text-red-600 dark:text-red-400">{{ $message }}</p> @enderror
    </div>

   
    {{--
    <div class="md:col-span-2">
        <label for="descripcion" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Descripción (Opcional)</label>
        <textarea id="descripcion" name="descripcion" rows="3" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-100 sm:text-sm">{{ old('descripcion', $formulario->descripcion ?? '') }}</textarea>
    </div>
     --}}
</div>