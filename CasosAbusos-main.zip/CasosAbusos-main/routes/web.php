<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Abogada\DashboardController as AbogadaDashboardController;
use App\Http\Controllers\Abogada\CasoController as AbogadaCasoController;
use App\Http\Controllers\Abogada\SeguimientoController as AbogadaSeguimientoController;
use App\Http\Controllers\Abogada\GestionFormularioController as AbogadaGestionFormularioController;
use App\Http\Controllers\Abogada\PreguntaController as AbogadaPreguntaController;
use App\Http\Controllers\Abogada\FormularioController as AbogadaFormularioController;
use App\Http\Controllers\Abogada\RespuestaController as AbogadaRespuestaController;

use App\Http\Controllers\Psicologa\PsicologaDashboardController;
use App\Http\Controllers\Psicologa\PsicologaCasoController;
use App\Http\Controllers\Psicologa\PsicologaSeguimientoController;

use App\Http\Controllers\Psicologa\GestionFormularioController as PsicologaGestionFormularioController;
use App\Http\Controllers\Psicologa\PreguntaController as PsicologaPreguntaController;
use App\Http\Controllers\Psicologa\FormularioController as PsicologaFormularioController;
use App\Http\Controllers\Psicologa\RespuestaController as PsicologaRespuestaController;

Route::get('/', function () {
    return view('auth.login');
});

Route::get('/dashboard', function () {
    if (auth()->check()) {
        if (auth()->user()->isAbogada()) {
            return redirect()->route('abogada.dashboard');
        } elseif (auth()->user()->isPsicologa()) {
            return redirect()->route('psicologa.dashboard');
        }
    }
    return view('auth.login');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::middleware(['auth', 'verified', 'role:abogada'])->prefix('abogada')->name('abogada.')->group(function () {
    Route::get('dashboard', [AbogadaDashboardController::class, 'index'])->name('dashboard');
    
    Route::resource('casos', AbogadaCasoController::class);
    Route::resource('casos.seguimientos', AbogadaSeguimientoController::class)->only(['store', 'destroy']);

    Route::resource('gestion-formularios', AbogadaGestionFormularioController::class);
    Route::resource('gestion-formularios.preguntas', AbogadaPreguntaController::class)->except(['index', 'show']);

    Route::get('casos/{caso}/formularios', [AbogadaFormularioController::class, 'index'])->name('formularios.index');
    Route::get('casos/{caso}/formularios/{formulario}', [AbogadaFormularioController::class, 'show'])->name('formularios.show');
    Route::post('formularios/{sesion}/respuestas', [AbogadaRespuestaController::class, 'store'])->name('respuestas.store');
    Route::get('sesiones/{sesion}', [AbogadaFormularioController::class, 'showSesion'])->name('sesiones.show');
});

Route::middleware(['auth', 'verified', 'role:psicologa'])->prefix('psicologa')->name('psicologa.')->group(function () {
    Route::get('dashboard', [PsicologaDashboardController::class, 'index'])->name('dashboard');
    
    Route::resource('casos', PsicologaCasoController::class);
    Route::resource('casos.seguimientos', PsicologaSeguimientoController::class)->only(['store', 'destroy']);

    Route::resource('gestion-formularios', PsicologaGestionFormularioController::class);
    Route::resource('gestion-formularios.preguntas', PsicologaPreguntaController::class)->except(['index', 'show']);

    Route::get('casos/{caso}/formularios', [PsicologaFormularioController::class, 'index'])->name('formularios.index');
    Route::get('casos/{caso}/formularios/{formulario}', [PsicologaFormularioController::class, 'show'])->name('formularios.show');
    Route::post('formularios/{sesion}/respuestas', [PsicologaRespuestaController::class, 'store'])->name('respuestas.store');
    Route::get('sesiones/{sesion}', [PsicologaFormularioController::class, 'showSesion'])->name('sesiones.show');
});

require __DIR__.'/auth.php';