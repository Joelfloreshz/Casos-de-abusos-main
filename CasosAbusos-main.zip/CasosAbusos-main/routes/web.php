<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Abogada\DashboardController as AbogadaDashboardController;
use App\Http\Controllers\Abogada\CasoController as AbogadaCasoController;
use App\Http\Controllers\Abogada\SeguimientoController as AbogadaSeguimientoController;
use App\Http\Controllers\Abogada\GestionFormularioController as AbogadaGestionFormularioController;
use App\Http\Controllers\Abogada\PreguntaController as AbogadaPreguntaController;
use App\Http\Controllers\Abogada\FormularioController as AbogadaFormularioController;
use App\Http\Controllers\Abogada\RespuestaController as AbogadaRespuestaController;

use App\Http\Controllers\Psicologa\PsicologaDashboardController;
use App\Http\Controllers\Psicologa\PsicologaCasoController;
use App\Http\Controllers\Psicologa\PsicologaSeguimientoController;
use App\Http\Controllers\Psicologa\GestionFormularioController as PsicologaGestionFormularioController;
use App\Http\Controllers\Psicologa\PreguntaController as PsicologaPreguntaController;
use App\Http\Controllers\Psicologa\FormularioController as PsicologaFormularioController;
use App\Http\Controllers\Psicologa\RespuestaController as PsicologaRespuestaController;

Route::get('/', function () {
    return view('auth.login');
});

Route::get('/dashboard', function () {
    if (auth()->check()) {
        if (auth()->user()->isAbogada()) {
            return redirect()->route('abogada.dashboard');
        } elseif (auth()->user()->isPsicologa()) {
            return redirect()->route('psicologa.dashboard');
        }
    }
    return view('auth.login');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

$roles = [
    'abogada' => [
        'dashboard' => AbogadaDashboardController::class,
        'casos' => AbogadaCasoController::class,
        'seguimientos' => AbogadaSeguimientoController::class,
        'gestion-formularios' => AbogadaGestionFormularioController::class,
        'preguntas' => AbogadaPreguntaController::class,
        'formularios' => AbogadaFormularioController::class,
        'respuestas' => AbogadaRespuestaController::class,
    ],
    'psicologa' => [
        'dashboard' => PsicologaDashboardController::class,
        'casos' => PsicologaCasoController::class,
        'seguimientos' => PsicologaSeguimientoController::class,
        'gestion-formularios' => PsicologaGestionFormularioController::class,
        'preguntas' => PsicologaPreguntaController::class,
        'formularios' => PsicologaFormularioController::class,
        'respuestas' => PsicologaRespuestaController::class,
    ]
];

foreach ($roles as $role => $controllers) {
    Route::middleware(['auth', 'verified', "role:$role", 'nocache'])
         ->prefix($role)
         ->name("$role.")
         ->group(function () use ($controllers) {
        
        Route::get('dashboard', [$controllers['dashboard'], 'index'])->name('dashboard');
        
        Route::resource('casos', $controllers['casos']);
        Route::resource('casos.seguimientos', $controllers['seguimientos'])->only(['store', 'destroy']);

        Route::resource('gestion-formularios', $controllers['gestion-formularios']);
        Route::resource('gestion-formularios.preguntas', $controllers['preguntas'])->except(['index', 'show']);

        Route::get('casos/{caso}/formularios', [$controllers['formularios'], 'index'])->name('formularios.index');
        Route::get('casos/{caso}/formularios/{formulario}', [$controllers['formularios'], 'show'])->name('formularios.show');
        Route::post('formularios/{sesion}/respuestas', [$controllers['respuestas'], 'store'])->name('respuestas.store');
        Route::get('sesiones/{sesion}', [$controllers['formularios'], 'showSesion'])->name('sesiones.show');
    });
}

require __DIR__.'/auth.php';